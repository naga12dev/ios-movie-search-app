//
//  Constants.swift
//  MovieBrowser
//
//  Created by mounika on 5/27/21.
//  Copyright © 2021 Lowe's Home Improvement. All rights reserved.
//

import Foundation

struct Constants {
    static let apikey = "2a61185ef6a27f400fd92820ad9e8537"
}
